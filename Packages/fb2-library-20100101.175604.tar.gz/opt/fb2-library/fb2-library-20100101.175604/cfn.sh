#!/bin/bash

SCRIPT=$0
SCRIPT_PATH=`dirname "$SCRIPT"`

java -Xms256M -Xmx512M -jar "$SCRIPT_PATH/fb2-library-20100101.175604.jar" cfn -input $1 -output $2 -outpath Library -outformat ZIP
