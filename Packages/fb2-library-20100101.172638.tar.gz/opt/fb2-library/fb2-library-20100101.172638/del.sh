#!/bin/bash

SCRIPT=$0
SCRIPT_PATH=`dirname "$SCRIPT"`

java -Xms256M -Xmx512M -jar "$SCRIPT_PATH/fb2-library-20100101.172638.jar" del -input $1
