#!/bin/bash

SCRIPT=$0
SCRIPT_PATH=`dirname "$SCRIPT"`

java -Xms512M -Xmx1024M -jar "$SCRIPT_PATH/fb2-library-1.0-rc6.jar" xml -input $1 -output $2
