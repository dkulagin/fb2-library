#!/bin/bash

SCRIPT=$0
SCRIPT_PATH=`dirname "$SCRIPT"`

java -Xms512M -Xmx1024M -cp "$SCRIPT_PATH/fb2-library-1.0-rc6.jar" org.ak2.fb2.library.Starter $*
