package fictionbook;

import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.awt.image.IndexColorModel;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.MemoryCacheImageInputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import net.iharder.Base64;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.traversal.NodeIterator;

import com.sun.org.apache.xpath.internal.XPathAPI;

import converter.FB2_2_MobiReader;

class COLOR_PALETTE {

  public static COLOR_PALETTE getMSVGAPalette() {
    COLOR_PALETTE pal = new COLOR_PALETTE();
    pal.R = pal.msvgar;
    pal.G = pal.msvgag;
    pal.B = pal.msvgab;
    return pal;
  }

  public static COLOR_PALETTE getRainbowPalette() {
    COLOR_PALETTE pal = new COLOR_PALETTE();
    int Loop;

    for (Loop = 0; Loop <= 42; ++Loop) {
      pal.R[Loop] = (byte) 255;
      pal.G[Loop] = (byte) ((int) Loop * 127 / 42);
      pal.B[Loop] = 0;
    }
    for (Loop = 43; Loop <= 84; ++Loop) {
      pal.R[Loop] = (byte) 255;
      pal.G[Loop] = (byte) (127 + (Loop - 43) * 128 / 41);
      pal.B[Loop] = 0;
    }
    for (Loop = 85; Loop <= 126; ++Loop) {
      pal.R[Loop] = (byte) (255 - (int) (Loop - 85) * 255 / 41);
      pal.G[Loop] = (byte) 255;
      pal.B[Loop] = 0;
    }
    for (Loop = 127; Loop <= 169; ++Loop) {
      pal.R[Loop] = 0;
      pal.G[Loop] = (byte) (255 - (int) (Loop - 127) * 255 / 42);
      pal.B[Loop] = (byte) ((int) (Loop - 127) * 255 / 42);
    }
    for (Loop = 170; Loop <= 211; ++Loop) {
      pal.R[Loop] = 0;
      pal.G[Loop] = 0;
      pal.B[Loop] = (byte) (255 - (int) (Loop - 170) * 128 / 41);
    }
    for (Loop = 212; Loop <= 245; ++Loop) {
      pal.R[Loop] = (byte) ((int) (Loop - 212) * 120 / 32);
      pal.G[Loop] = 0;
      pal.B[Loop] = 127;
    }

    for (Loop = 246; Loop <= 255; ++Loop) {
      pal.R[Loop] = (byte) ((int) (Loop - 246) * 255 / 9);
      pal.G[Loop] = (byte) ((int) (Loop - 246) * 255 / 9);
      pal.B[Loop] = (byte) ((int) (Loop - 246) * 255 / 9);
    }
    return pal;
  }

  public static COLOR_PALETTE getGrayScalePalette() {
    COLOR_PALETTE pal = new COLOR_PALETTE();
    int Loop;

    for (Loop = 0; Loop <= 255; ++Loop) {
      pal.R[Loop] = (byte) Loop;
      pal.G[Loop] = (byte) Loop;
      pal.B[Loop] = (byte) Loop;
    }
    return pal;
  }

  private byte msvgab[] = {0, 42, 0, 42, 0, 42, 0, 42, 21, 63, 21, 63, 21,
      63, 21, 63, 0, 5, 8, 11, 14, 17, 20, 24, 28, 32, 36, 40, 45, 50, 56,
      63, 63, 63, 63, 63, 63, 47, 31, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16,
      31, 47, 63, 63, 63, 63, 63, 63, 63, 63, 63, 55, 47, 39, 31, 31, 31,
      31, 31, 31, 31, 31, 31, 39, 47, 55, 63, 63, 63, 63, 63, 63, 63, 63,
      63, 58, 54, 49, 45, 45, 45, 45, 45, 45, 45, 45, 45, 49, 54, 58, 63,
      63, 63, 63, 28, 28, 28, 28, 28, 21, 14, 7, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 7, 14, 21, 28, 28, 28, 28, 28, 28, 28, 28, 28, 24, 21, 17, 14,
      14, 14, 14, 14, 14, 14, 14, 14, 17, 21, 24, 28, 28, 28, 28, 28, 28,
      28, 28, 28, 26, 24, 22, 20, 20, 20, 20, 20, 20, 20, 20, 20, 22, 24,
      26, 28, 28, 28, 28, 16, 16, 16, 16, 16, 12, 8, 4, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 4, 8, 12, 16, 16, 16, 16, 16, 16, 16, 16, 16, 14, 12, 10,
      8, 8, 8, 8, 8, 8, 8, 8, 8, 10, 12, 14, 16, 16, 16, 16, 16, 16, 16,
      16, 16, 15, 13, 12, 11, 11, 11, 11, 11, 11, 11, 11, 11, 12, 13, 15,
      16, 16, 16, 16, 0, 0, 0, 0, 0, 0, 0, 0};

  private byte msvgag[] = {0, 0, 42, 42, 0, 0, 21, 42, 21, 21, 63, 63, 21,
      21, 63, 63, 0, 5, 8, 11, 14, 17, 20, 24, 28, 32, 36, 40, 45, 50, 56,
      63, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 31, 47, 63, 63, 63, 63, 63, 63,
      63, 63, 63, 47, 31, 16, 31, 31, 31, 31, 31, 31, 31, 31, 31, 39, 47,
      55, 63, 63, 63, 63, 63, 63, 63, 63, 63, 55, 47, 39, 45, 45, 45, 45,
      45, 45, 45, 45, 45, 49, 54, 58, 63, 63, 63, 63, 63, 63, 63, 63, 63,
      58, 54, 49, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 14, 21, 28, 28, 28, 28,
      28, 28, 28, 28, 28, 21, 14, 7, 14, 14, 14, 14, 14, 14, 14, 14, 14,
      17, 21, 24, 28, 28, 28, 28, 28, 28, 28, 28, 28, 24, 21, 17, 20, 20,
      20, 20, 20, 20, 20, 20, 20, 22, 24, 26, 28, 28, 28, 28, 28, 28, 28,
      28, 28, 26, 24, 22, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 8, 12, 16, 16, 16,
      16, 16, 16, 16, 16, 16, 12, 8, 4, 8, 8, 8, 8, 8, 8, 8, 8, 8, 10, 12,
      14, 16, 16, 16, 16, 16, 16, 16, 16, 16, 14, 12, 10, 11, 11, 11, 11,
      11, 11, 11, 11, 11, 12, 13, 15, 16, 16, 16, 16, 16, 16, 16, 16, 16,
      15, 13, 12, 0, 0, 0, 0, 0, 0, 0, 0};

  private byte msvgar[] = {0, 0, 0, 0, 42, 42, 42, 42, 21, 21, 21, 21, 63,
      63, 63, 63, 0, 5, 8, 11, 14, 17, 20, 24, 28, 32, 36, 40, 45, 50, 56,
      63, 0, 16, 31, 47, 63, 63, 63, 63, 63, 63, 63, 63, 63, 47, 31, 16,
      0, 0, 0, 0, 0, 0, 0, 0, 31, 39, 47, 55, 63, 63, 63, 63, 63, 63, 63,
      63, 63, 55, 47, 39, 31, 31, 31, 31, 31, 31, 31, 31, 45, 49, 54, 58,
      63, 63, 63, 63, 63, 63, 63, 63, 63, 58, 54, 49, 45, 45, 45, 45, 45,
      45, 45, 45, 0, 7, 14, 21, 28, 28, 28, 28, 28, 28, 28, 28, 28, 21,
      14, 7, 0, 0, 0, 0, 0, 0, 0, 0, 14, 17, 21, 24, 28, 28, 28, 28, 28,
      28, 28, 28, 28, 24, 21, 17, 14, 14, 14, 14, 14, 14, 14, 14, 20, 22,
      24, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 26, 24, 22, 20, 20, 20,
      20, 20, 20, 20, 20, 0, 4, 8, 12, 16, 16, 16, 16, 16, 16, 16, 16, 16,
      12, 8, 4, 0, 0, 0, 0, 0, 0, 0, 0, 8, 10, 12, 14, 16, 16, 16, 16, 16,
      16, 16, 16, 16, 14, 12, 10, 8, 8, 8, 8, 8, 8, 8, 8, 11, 12, 13, 15,
      16, 16, 16, 16, 16, 16, 16, 16, 16, 15, 13, 12, 11, 11, 11, 11, 11,
      11, 11, 11, 0, 0, 0, 0, 0, 0, 0, 0};

  public byte B[];

  public byte G[];

  public byte R[];

  private COLOR_PALETTE() {
    B = new byte[256];
    G = new byte[256];
    R = new byte[256];
  }
}

/**
 * @author Whippet
 */


public class FictionBook {
  private String fieldBookName;

  private byte[] fieldContent;

  private Document fieldDocument;

  //	private String fieldFileName;

  private HashMap fieldImageIndexes = new HashMap();

  private LinkedList fieldImages = new LinkedList();

  private HashMap fieldHrefs;

  //	private File fb2File;

  private InputStream fb2InputStream;

  public FictionBook(InputStream is) {
    //		fieldFileName = fileName;
    //		System.out.println("Loading file: " + fileName);
    //		fb2File = new File(fieldFileName);
    fb2InputStream = is;
  }

  protected boolean extractImages() {
    long imageIndex = 1;
    System.out.println("Extracting images...");
    try {
      NodeIterator iter = XPathAPI.selectNodeIterator(fieldDocument
          .getDocumentElement(), "/FictionBook/binary");
      for (Node node = iter.nextNode(); node != null; node = iter
          .nextNode()) {
        Element element = (Element) node;
        String imageFileName = element.getAttribute("id");
        String imageMineType = element.getAttribute("content-type");

        System.out.println("Image " + imageIndex + ": " + imageFileName);

        fieldImageIndexes.put(imageFileName, new Long(imageIndex++));

        String encoded = element.getFirstChild().getNodeValue();

        byte[] decoded = Base64.decode(encoded);

        Iterator readersIterator = ImageIO
            .getImageReadersByMIMEType(imageMineType);

        if (readersIterator.hasNext()) {
          ImageReader reader = (ImageReader) readersIterator.next();

          reader.setInput(new MemoryCacheImageInputStream(
              new ByteArrayInputStream(decoded)), true, true);

          BufferedImage image = null;
          try {
            image = reader.read(0);
            transformImage(imageFileName, image);
          } catch (RuntimeException e) {
            System.out.println("Image extraction failed. Skipping.");
            continue;
          }

        }
      }
      System.out.println("Images extracted successfully");
      return true;
    } catch (Throwable th) {
      th.printStackTrace();
    }
    System.out.println("Images extraction failed");
    return false;
  }

  private void transformImage(String imageFileName, BufferedImage image)
    throws FileNotFoundException, IOException {
    FileOutputStream output = new FileOutputStream(FB2_2_MobiReader
        .getFileName(imageFileName, "BMP"));

    double scale = Math.min((double) 300 / image.getWidth(), (double) 300
        / image.getHeight());

    if (scale > 1) {
      scale = 1.0;
    }
    int width = (int) (Math.round(scale * image.getWidth()));
    int height = (int) (Math.round(scale * image.getHeight()));

    while (width * height > 64000) {
      scale = scale * 0.9;
      width = (int) (Math.round(scale * image.getWidth()));
      height = (int) (Math.round(scale * image.getHeight()));
    }

    AffineTransformOp op1 = new AffineTransformOp(AffineTransform
        .getScaleInstance(scale, scale),
        AffineTransformOp.TYPE_NEAREST_NEIGHBOR);

    BufferedImage scaledImage = op1.filter(image, new BufferedImage(width,
        height, image.getType()));

    COLOR_PALETTE pal = COLOR_PALETTE.getRainbowPalette();

    final IndexColorModel BINARY_COLOR_MODEL = new IndexColorModel(8, 256,
        pal.R, pal.G, pal.B, -1);

    int w = scaledImage.getWidth();
    int h = scaledImage.getHeight();

    BufferedImage bufferedImage = new BufferedImage(w, h,
        BufferedImage.TYPE_BYTE_INDEXED, BINARY_COLOR_MODEL);

    bufferedImage.getGraphics().drawImage(scaledImage, 0, 0, null);

    ImageIO.write(bufferedImage, "bmp", output);
    output.flush();
    output.close();

    fieldImages.add(FB2_2_MobiReader.getFileName(imageFileName, "BMP"));
  }

  private boolean extractName() {
    try {
      NodeIterator iter = XPathAPI.selectNodeIterator(fieldDocument
          .getDocumentElement(),
          "/FictionBook/description/title-info/book-title");
      Element element = (Element) iter.nextNode();
      fieldBookName = element.getFirstChild().getNodeValue();

      System.out.println("Found book-name: " + fieldBookName);

      return true;
    } catch (Throwable th) {
      th.printStackTrace();
    }
    return false;
  }

  public String getBookName() {
    return fieldBookName;
  }

  public byte[] getContent() {
    return fieldContent;
  }

  public String[] getImages() {
    return (String[]) fieldImages.toArray(new String[fieldImages.size()]);
  }

  public boolean load() {
    return parse() && updateImageLinks() && extractImages()
        && setImageIndexes() && extractName();
  }

  protected boolean parse() {
    System.out.println("Parsing...");
    try {
      DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
      // f.setNamespaceAware(true);
      DocumentBuilder b = f.newDocumentBuilder();
      fieldDocument = b.parse(fb2InputStream);
      System.out.println("FB2 file parsed succefully");
      return true;
    } catch (Throwable th) {
      th.printStackTrace();
    }
    System.out.println("FB2 file parse failed");
    return false;
  }

  protected boolean updateImageLinks() {
    System.out.println("Updating Image Links...");
    try {
      NodeIterator iter2 = XPathAPI.selectNodeIterator(fieldDocument
          .getDocumentElement(), "//image");
      for (Node node = iter2.nextNode(); node != null; node = iter2
          .nextNode()) {
        Element element = (Element) node;
        String href = element.getAttribute("xlink:href");
        if (href.length() > 0) {
          element.setAttribute("l:href", href);
        }
      }
      System.out.println("Image links updated successfully");
      return true;
    } catch (Throwable th) {
      th.printStackTrace();
    }
    System.out.println("Image links update failed");
    return false;
  }

  protected boolean setImageIndexes() {
    System.out.println("Updating Image indexes...");
    try {
      NodeIterator iter2 = XPathAPI.selectNodeIterator(fieldDocument
          .getDocumentElement(), "//image");
      for (Node node = iter2.nextNode(); node != null; node = iter2
          .nextNode()) {
        Element element = (Element) node;
        String imageName = element.getAttribute("l:href");
        if (imageName.startsWith("#")) {
          imageName = imageName.substring(1);
        }
        if (fieldImageIndexes.containsKey(imageName)) {
          Long index = (Long) fieldImageIndexes.get(imageName);
          element.setAttribute("prctype", "BMP");

          String indexString = "" + index;

          int j = indexString.length();
          for (int i = 0; i < 5 - j; i++)
            indexString = "0" + indexString;

          element.setAttribute("prcindex", indexString);
        }
      }
      System.out.println("Image indexes updated successfully");
      return true;
    } catch (Throwable th) {
      th.printStackTrace();
    }
    System.out.println("Image indexes update failed");
    return false;
  }

  public boolean transform() {
    System.out.println("Transforming fb2 document...");
    try {
      StreamSource xslForHtml = new StreamSource(getClass()
          .getResourceAsStream("/xsl/FB2_2_html_ru.xsl"));

      ByteArrayOutputStream output = new ByteArrayOutputStream();

      DOMSource fb2FileSource = new DOMSource(fieldDocument);
      StreamResult htmlFile = new StreamResult(output);

      Transformer t = TransformerFactory.newInstance().newTransformer(
          xslForHtml);
     
      
      t.transform(fb2FileSource, htmlFile);

      fieldContent = output.toByteArray();

      System.out.println("Transformation completed successfully");

      return true;
    } catch (Throwable th) {
      th.printStackTrace();
    }
    System.out.println("Transformation failed");
    return false;
  }

  /**
   * @return
   */
  public boolean correctHREFs() {
    try {
      System.out.println("Correcting hrefs");
      String content = new String(getContent(),"windows-1251");

      fieldHrefs = new HashMap();
      int index = content.indexOf("<a name=\"", 0);

      while (index != -1) {
        String xrefName = content.substring(index + 9, content.indexOf(
            "\"", index + 9));
        while (xrefName.startsWith("#")) {
          xrefName = xrefName.substring(1);
        }

        int hrefIndex = content.indexOf("<div>", index-30);
        
        String xrefValue = generateXrefValue(hrefIndex);

        System.out.println("Found href=" + xrefName + " at filepos="
            + xrefValue);
        index = content.indexOf("<a name=\"", index + 10
            + xrefName.length());

        fieldHrefs.put(xrefName, xrefValue);
      }

      int maxIndex = 0;

      for (Iterator it = fieldHrefs.keySet().iterator(); it.hasNext();) {
        String name = (String) it.next();

        String searchPattern = "<a filepos=\"000000000\" href=\"#" + name
            + "\"";

        int index1 = content.indexOf(searchPattern);
        if (index1 > maxIndex) {
          maxIndex = index1;
        }
      }

      String header = content.substring(0, maxIndex + 100);

      for (Iterator it = fieldHrefs.keySet().iterator(); it.hasNext();) {
        String name = (String) it.next();
        String value = (String) fieldHrefs.get(name);

        String searchPattern = "<a filepos=\"000000000\" href=\"#" + name
            + "\"";
        String replaceString = "<A HREF=\"#" + name + "\" filepos=\""
            + value + "\"";
        int index1 = header.indexOf(searchPattern);
        if (index1 > 0) {
          header = header.substring(0, index1) + replaceString
              + header.substring(index1 + searchPattern.length());
        }
      }

      content = header + content.substring(maxIndex + 100);
  /*    
        for (Iterator it = fieldHrefs.keySet().iterator(); it.hasNext();) {
        String name = (String) it.next();
        
        String searchPattern = "<a name=\"" + name + "\"/>"; String
        replaceString = " <a> </a> "; replaceString =
        replaceString.substring(0, searchPattern.length());
        int index1 =    content.indexOf(searchPattern); if (index1 > 0) { content =
        content.substring(0, index1) + replaceString + content.substring(index1 +
        searchPattern.length()); } }
    */   
      fieldContent = content.getBytes("windows-1251");
      System.out.println("HREFs corrected");
   /*   
        FileOutputStream fs = new FileOutputStream("f:\\out.html");
        fs.write(fieldContent); fs.close();
     */  
      return true;

    } catch (Throwable th) {
      th.printStackTrace();
    }

    System.out.println("Correction hrefs failed");
    return false;
  }

  /**
   * @param index
   * @return
   */
  private String generateXrefValue(int index) {
    int idx = index;
    String result = "" + (idx);
    int l = result.length();
    for (int i = 0; i < 9 - l; i++)
      result = "0" + result;

    return result;
  }

  public HashMap getHrefs() {
    return fieldHrefs;
  }
}