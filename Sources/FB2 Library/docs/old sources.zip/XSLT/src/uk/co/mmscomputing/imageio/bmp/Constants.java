package uk.co.mmscomputing.imageio.bmp;

public interface Constants{
  static final public int BI_RGB       =0x00;
  static final public int BI_RLE8      =0x01;
  static final public int BI_RLE4      =0x02;
  static final public int BI_BITFIELDS =0x03;
}