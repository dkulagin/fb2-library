package converter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import fictionbook.FictionBook;

public class FB2_2_MobiReader {
	private static String defaultOutputPath = ":";

	public static void main(String[] args) {
		if (args.length < 1) {
			showReadme();
			System.exit(0);
		}
		if (args.length >= 2) {
			File f = new File(args[1]);
			if (f.isDirectory()) {
				defaultOutputPath = f.getAbsolutePath();
			}
		}
		try {
			String consoleEnc = System.getProperty("console.encoding", "Cp866");
			System.setOut(new PrintStream(System.out, true, consoleEnc));
			System.setErr(new PrintStream(System.err, true, consoleEnc));
		} catch (UnsupportedEncodingException e) {
			System.out.println("Unable to setup console codepage: " + e);
		}

		try {

			String fileName = args[0];
			File f = new File(fileName);
			generate(f);
			System.out.println("Transformation finished.");
		} catch (Throwable th) {
			th.printStackTrace();
		}

	}

	private static void generate(File inputFile) throws IOException {
		String fileName = inputFile.getCanonicalPath();
		System.out.println("Loading file: " + fileName);

		if (inputFile.isDirectory()) {
			File[] files = inputFile.listFiles();
			for (int i = 0; i < files.length; i++) {
				generate(files[i]);
			}
		} else {
			if (fileName.endsWith("fb2")) {
				String outputFileName;
				if (":".equals(defaultOutputPath)) {
					outputFileName = getFileName(fileName, "prc");
				} else {
					outputFileName = getFileName(defaultOutputPath + "\\"
							+ inputFile.getName(), "prc");
				}
				InputStream fs = new FileInputStream(inputFile);
				FictionBook fb = new FictionBook(fs);

				if (fb.load() && fb.transform() && fb.correctHREFs()) {
	/*				
				  	File f = new File(getFileName(fileName, "txt"));
				  	FileWriter fw = new FileWriter(f);
				  	fw.write(new String(fb.getContent()));
				  	fw.close();
*/
					EBookPrc prc = new EBookPrc(outputFileName);

					prc.generate(fb);
				}
				return;
			}
			if (fileName.endsWith("zip")) {
				ZipFile zipFile = new ZipFile(inputFile);
				Enumeration entries = zipFile.entries();
				while (entries.hasMoreElements()) {
					ZipEntry element = (ZipEntry) entries.nextElement();
					if (!element.isDirectory()) {
						String name = element.getName();
						if (name.endsWith("fb2")) {

							String fileInZIP;
							if (":".equals(defaultOutputPath)) {
								fileInZIP = inputFile.getParent() + "\\" + name;
							} else {
								fileInZIP = defaultOutputPath + "\\" + name;
							}
							String outputFileName = getFileName(fileInZIP,
									"prc");
							InputStream fs = zipFile.getInputStream(element);
							FictionBook fb = new FictionBook(fs);

							if (fb.load() && fb.transform()
									&& fb.correctHREFs()) {

								EBookPrc prc = new EBookPrc(outputFileName);

								prc.generate(fb);
							}
						}
					}
				}
				zipFile.close();
				return;
			}
			System.out.println("Skipping...");
		}
	}

	/**
	 * Shows help text
	 */
	private static void showReadme() {
		try {
			BufferedReader readme = new BufferedReader(new InputStreamReader(
					FB2_2_MobiReader.class.getClassLoader()
							.getResourceAsStream("readme.txt")));
			for (String s = readme.readLine(); s != null; s = readme.readLine()) {
				System.out.println(s);
			}
		} catch (IOException ex) {
		}
	}

	public static String getFileName(String original, String ext) {
		int pos = original.lastIndexOf('.');
		if (pos >= 0) {
			return original.substring(0, pos) + "." + ext;
		} else {
			return original + "." + ext;
		}
	}
}
