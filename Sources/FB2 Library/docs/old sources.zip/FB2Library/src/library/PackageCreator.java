package library;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * The Class PackageCreator. Creates output zip file package.
 * 
 * @author Komarovskikh Andrei
 */
public class PackageCreator {

  /** The output zip file. */
  private ZipOutputStream outputZipFile;

  /**
   * The Constructor.
   * 
   * @param outFilename the out filename
   * @throws FileNotFoundException the file not found exception
   */
  public PackageCreator(final String outFilename) throws FileNotFoundException {
    outputZipFile = new ZipOutputStream(new FileOutputStream(outFilename));
  }

  /**
   * Adds the file to package.
   * 
   * @param inputFile the input file
   * @throws IOException the IO exception
   */
  public void addFileToPackage(final String inputFile)
    throws IOException {
    // Create a buffer for reading the files
    final byte[] buf = new byte[1024];

    // Compress the file
    final FileInputStream in = new FileInputStream(inputFile);

    final String entryName = getFileName(inputFile);
    // Add ZIP entry to output stream.
    outputZipFile.putNextEntry(new ZipEntry(entryName));

    // Transfer bytes from the file to the ZIP file
    int len;
    while ((len = in.read(buf)) > 0) {
      outputZipFile.write(buf, 0, len);
    }
    // Complete the entry
    outputZipFile.closeEntry();
    in.close();
  }

  /**
   * Adds content of the stream to package.
   * 
   * @param inputFileName the input file name
   * @throws IOException the IO exception
   */
  public void addFileToPackage(final InputStream inStream, final String inputFileName)
    throws IOException {
    
    // Create a buffer for reading the files
    final byte[] buf = new byte[1024];

    final String entryName = toTranslit(inputFileName);
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    CRC32 crc32 = new CRC32();
    

    // Transfer bytes from the file to the ZIP file
    int len, length = 0;
    while ((len = inStream.read(buf)) > 0) {
      bos.write(buf, 0, len);
      crc32.update(buf, 0, len);
      length += len;
    }
    byte[] bytes = bos.toByteArray();
    ZipEntry zipEntry = new ZipEntry(entryName);
    ZipOutputStream fakeZip = new ZipOutputStream(new ByteArrayOutputStream());
    fakeZip.putNextEntry(zipEntry);
    fakeZip.write(bytes);
    fakeZip.closeEntry();
	
	// Add ZIP entry to output stream.
    outputZipFile.putNextEntry(zipEntry);
    outputZipFile.write(bytes);

    // Complete the entry
    outputZipFile.closeEntry();
    inStream.close();
  }
  
  private static HashMap<String, String> map = new HashMap<String, String>();
  static {
    map.put("�", "a");
    map.put("�", "b");
    map.put("�", "v");
    map.put("�", "g");
    map.put("�", "d");
    map.put("�", "e");
    map.put("�", "jo");
    map.put("�", "zh");
    map.put("�", "z");
    map.put("�", "i");
    map.put("�", "j");
    map.put("�", "k");
    map.put("�", "l");
    map.put("�", "m");
    map.put("�", "n");
    map.put("�", "o");
    map.put("�", "p");
    map.put("�", "r");
    map.put("�", "s");
    map.put("�", "t");
    map.put("�", "u");
    map.put("�", "f");
    map.put("�", "h");
    map.put("�", "c");
    map.put("�", "ch");
    map.put("�", "sh");
    map.put("�", "shch");
    map.put("�", "");
    map.put("�", "y");
    map.put("�", "'");
    map.put("�", "ye");
    map.put("�", "ju");
    map.put("�", "ja");
    map.put(" ", "_");
  }
  
  private String toTranslit(String inputFile) {
    inputFile = inputFile.toLowerCase();
    StringBuffer out = new StringBuffer();
    for (int i = 0; i < inputFile.length(); i++) {
      char charAt = inputFile.charAt(i);
      String mapped = map.get(new String(new char[]{charAt}));
      if (mapped != null) {
        out.append(mapped);
      }
      else {
        out.append(charAt);
      }
    }
    return out.toString();
  }

  /**
   * Close.
   */
  public void close() {
    try {
      outputZipFile.close();
    } catch (final IOException e) {
    }
  }

  /**
   * Retrieves only filename from absolute or relative file path.
   * 
   * @param string the string
   * @return the file name
   */
  private String getFileName(final String string) {
    final File f = new File(string);
    return f.getName();
  }
}
