package library;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.traversal.NodeIterator;
import org.xml.sax.SAXException;

import com.sun.org.apache.xpath.internal.XPathAPI;

public class FictionBook {

	private Document fieldDocument;

	private String fieldBookName = null;

	private String fieldAuthor;

	public FictionBook(InputStream inStream) throws SAXException {
		DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
		DocumentBuilder b;
		try {
			b = f.newDocumentBuilder();
			fieldDocument = b.parse(inStream);
			System.out.println("FB2 file parsed succefully");
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String getBookName() {
		if (fieldDocument == null)
			return null;

		if (fieldBookName != null)
			return fieldBookName;

		try {
			NodeIterator iter = XPathAPI.selectNodeIterator(fieldDocument
					.getDocumentElement(),
					"/FictionBook/description/title-info/book-title");
			Element element = (Element) iter.nextNode();
			fieldBookName = element.getFirstChild().getNodeValue().trim();

			return fieldBookName;

		} catch (Throwable th) {
			th.printStackTrace();
		}

		return null;
	}

	public void setBookName(String bookname) {
		if (fieldDocument == null) {
			return;
		}
		try {
			NodeIterator iter = XPathAPI.selectNodeIterator(fieldDocument
					.getDocumentElement(),
					"/FictionBook/description/title-info/book-title");
			Element element = (Element) iter.nextNode();
			element.getFirstChild().setNodeValue(bookname);

		} catch (Throwable th) {
			th.printStackTrace();
		}
	}

	public String getAuthor() {
		if (fieldDocument == null)
			return null;

		if (fieldAuthor != null)
			return fieldAuthor;

		try {
			fieldAuthor = (getAuthorLastName() + " " + getAuthorFirstName())
					.trim();

			return fieldAuthor;

		} catch (Throwable th) {
			th.printStackTrace();
		}

		return null;
	}

	private String getAuthorFirstName() {
		try {
			NodeIterator iter = XPathAPI.selectNodeIterator(fieldDocument
					.getDocumentElement(),
					"/FictionBook/description/title-info/author/first-name");
			Element element = (Element) iter.nextNode();
			String fieldAuthorFirstName = element.getFirstChild()
					.getNodeValue();

			return fieldAuthorFirstName;

		} catch (Throwable th) {
		}
		return "";
	}

	private String getAuthorLastName() {
		try {
			NodeIterator iter = XPathAPI.selectNodeIterator(fieldDocument
					.getDocumentElement(),
					"/FictionBook/description/title-info/author/last-name");
			Element element = (Element) iter.nextNode();
			String fieldAuthorLastName = element.getFirstChild().getNodeValue();

			return fieldAuthorLastName;

		} catch (Throwable th) {
		}

		return "";
	}

	public InputStream getBookStream()
			throws TransformerFactoryConfigurationError, TransformerException {
		ByteArrayOutputStream output = new ByteArrayOutputStream();

		try {
			output
					.write("<?xml version=\"1.0\" encoding=\"windows-1251\" standalone=\"no\"?>"
							.getBytes());
		} catch (IOException e) {
		}
		DOMSource fb2FileSource = new DOMSource(fieldDocument);
		StreamResult htmlFile = new StreamResult(output);

		Transformer t = TransformerFactory.newInstance().newTransformer();
		t.setOutputProperty(OutputKeys.ENCODING, "windows-1251");
		t.setOutputProperty(OutputKeys.METHOD, "xml");
		t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");

		t.transform(fb2FileSource, htmlFile);

		byte[] fieldContent = output.toByteArray();

		return new ByteArrayInputStream(fieldContent);
	}

	public String getSequence() {
		try {
			NodeIterator iter = XPathAPI.selectNodeIterator(fieldDocument
					.getDocumentElement(),
					"/FictionBook/description/title-info/sequence");
			Element element = (Element) iter.nextNode();
			String fieldSeq = element.getAttribute("name");

			return fieldSeq.trim();

		} catch (Throwable th) {
		}

		return "";
	}

	public void setSequence(String sequence) {
		try {
			NodeIterator iter = XPathAPI.selectNodeIterator(fieldDocument
					.getDocumentElement(),
					"/FictionBook/description/title-info/sequence");
			Element element = (Element) iter.nextNode();
			if (element == null) {
				// Create node
				NodeIterator iter1 = XPathAPI.selectNodeIterator(fieldDocument
						.getDocumentElement(),
						"/FictionBook/description/title-info");
				Element titleInfo = (Element) iter1.nextNode();
				element = fieldDocument.createElement("sequence");
				titleInfo.appendChild(element);
			}
			element.setAttribute("name", sequence);

		} catch (Throwable th) {
			th.printStackTrace();
		}
	}

	public String getSequenceNo() {
		try {
			NodeIterator iter = XPathAPI.selectNodeIterator(fieldDocument
					.getDocumentElement(),
					"/FictionBook/description/title-info/sequence");
			Element element = (Element) iter.nextNode();
			String fieldSeq = element.getAttribute("number");

			return fieldSeq.trim();

		} catch (Throwable th) {
		}

		return "";
	}

	public void setSequenceNo(String no) {
		try {
			NodeIterator iter = XPathAPI.selectNodeIterator(fieldDocument
					.getDocumentElement(),
					"/FictionBook/description/title-info/sequence");
			Element element = (Element) iter.nextNode();
			if (element == null) {
				// Create node
				NodeIterator iter1 = XPathAPI.selectNodeIterator(fieldDocument
						.getDocumentElement(),
						"/FictionBook/description/title-info");
				Element titleInfo = (Element) iter1.nextNode();
				element = fieldDocument.createElement("sequence");
				titleInfo.appendChild(element);
			}
			element.setAttribute("number", no);
		} catch (Throwable th) {
		}
	}

}
