/*
 * Created on 24.01.2007
 */
package library;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;

import org.xml.sax.SAXException;

/**
 * @author Andrei Komarovskikh / Reksoft
 */
public class Main {

	public static void main(String[] args) {
		System.setProperty(
				"com.sun.org.apache.xalan.internal.serialize.encodings",
				Main.class.getResource("Encodings.properties").toString());
		if (args.length < 1) {
			showReadme();
			System.exit(0);
		}
		// try {
		// String consoleEnc = System.getProperty("console.encoding", "866");
		// System.setOut(new PrintStream(System.out, true, consoleEnc));
		// System.setErr(new PrintStream(System.err, true, consoleEnc));
		// } catch (UnsupportedEncodingException e) {
		// System.out.println("Unable to setup console codepage: " + e);
		// }

		for (int i = 0; i < args.length; i++) {
			String cmdArg = args[i];

			if (cmdArg.equalsIgnoreCase("cfn")) {
				convertFileNames(args, false);
				System.exit(0);
			}
			if (cmdArg.equalsIgnoreCase("cfnd")) {
				convertFileNames(args, true);
				System.exit(0);
			}
			if (cmdArg.equalsIgnoreCase("fsd")) {
				fixSequenceDeclaration(args);
				System.exit(0);
			}

		}

	}

	private static void fixSequenceDeclaration(String[] args) {
		if (args.length < 3) {
			System.out
					.println("Not enough input parameters for 'Fix Sequence Declaration'");
			showReadme();
			System.exit(0);
		}
		String inputFolder = "";
		for (int i = 0; i < args.length; i++) {
			if (args[i].equalsIgnoreCase("-input") && (i + 1 < args.length)) {
				inputFolder = args[i + 1];
				i++;
			}
		}

		if (inputFolder.length() == 0) {
			System.out.println("Input folder is missing");
			System.exit(0);
		}

		System.out.println("Processing input folder: " + inputFolder);
		File inFile = new File(inputFolder);

		fsd(inFile);

	}

	private static void fsd(File inFile) {
		String fileName;
		fileName = inFile.getName();

		if (inFile.isDirectory()) {
			File[] files = inFile.listFiles();
			for (int i = 0; i < files.length; i++) {
				fsd(files[i]);
			}
		} else {
			Pattern pattern = Pattern.compile("^(.+)\\((.+)\\s-\\s([0-9]+)\\)");
			Matcher matcher = pattern.matcher(fileName);
			if (matcher.find()) {
				/*
				 * System.out.println("Found suspicious name!");
				 * System.out.println("File: "+inFile.getAbsolutePath());
				 * System.out.println("Bookname: "+matcher.group(1));
				 * System.out.println("Sequence: "+matcher.group(2));
				 * System.out.println("Order: "+matcher.group(3));
				 * System.out.println("======================");
				 */
				boolean isZipFile = false;
				ZipFile zipFile = null;
				try {
					InputStream inStream = null;
					if (fileName.endsWith(".fb2")) {
						inStream = new FileInputStream(inFile);
					}
					if (fileName.endsWith(".zip")) {

						try {
							zipFile = new ZipFile(inFile);
							isZipFile = true;
						} catch (ZipException e) {
							e.printStackTrace();
							System.out
									.println("File "
											+ fileName
											+ " can not be transformed. Skipping to next file");
							return;
						} catch (IOException e) {
							e.printStackTrace();
							System.out
									.println("File "
											+ fileName
											+ " can not be transformed. Skipping to next file");
							return;
						}
						Enumeration<? extends ZipEntry> entries = zipFile
								.entries();
						while (entries.hasMoreElements()) {
							ZipEntry element = entries.nextElement();
							if (!element.isDirectory()) {
								String name = element.getName();
								if (name.endsWith("fb2")) {
									try {
										inStream = zipFile
												.getInputStream(element);
										break;
									} catch (Throwable e) {
										e.printStackTrace();
										System.out
												.println("File "
														+ fileName
														+ " can not be transformed. Skipping to next file");

									}
								}
							}
						}
					}
					if (inStream != null) {
						FictionBook book = new FictionBook(inStream);
						book.setBookName(matcher.group(1));
						book.setSequence(matcher.group(2));
						book.setSequenceNo(matcher.group(3));
						renameFile(book.getBookStream(), inFile.getParentFile()
								.getParent());
						inFile.delete();
					}

				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (SAXException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (TransformerFactoryConfigurationError e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (TransformerException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					if (isZipFile && zipFile != null) {
						try {
							zipFile.close();
						} catch (IOException e) {
							e.printStackTrace();
							System.out
									.println("File "
											+ fileName
											+ " can not be transformed. Skipping to next file");
							return;
						}

					}
				}

			}
		}
	}

	private static void convertFileNames(String[] args, boolean delete) {
		if (args.length < 5) {
			System.out
					.println("Not enough input parameters for 'Convert File Names'");
			showReadme();
			System.exit(0);
		}

		// parsing parameters
		String inputFolder = "";
		String outputFolder = "";

		for (int i = 0; i < args.length; i++) {
			if (args[i].equalsIgnoreCase("-input") && (i + 1 < args.length)) {
				inputFolder = args[i + 1];
				i++;
			}
			if (args[i].equalsIgnoreCase("-output") && (i + 1 < args.length)) {
				outputFolder = args[i + 1];
				i++;
			}
		}

		if (inputFolder.length() == 0) {
			System.out.println("Input folder is missing");
			System.exit(0);
		}

		if (outputFolder.length() == 0) {
			System.out.println("Output folder is missing");
			System.exit(0);
		}

		System.out.println("Processing input folder: " + inputFolder);
		System.out.println("Writing output into: " + outputFolder);

		File inFile = new File(inputFolder);

		renameFile(inFile, outputFolder, delete);
	}

	private static void renameFile(File inFile, String outputFolder,
			boolean delete)/*
							 * throws IOException,
							 * TransformerFactoryConfigurationError,
							 * TransformerException
							 */{
		String fileName;
		try {
			fileName = inFile.getCanonicalPath();
		} catch (IOException e) {
			System.out
					.println("Error getting canonical filename. Skipping to next file");
			return;
		}
		Date curTime = new Date();
		System.out.println(MessageFormat.format(
				"{0,date,yyyy.MM.dd HH:mm:ss} Loading file: {1}", curTime,
				fileName));

		if (inFile.isDirectory()) {
			File[] files = inFile.listFiles();
			Arrays.sort(files, new Comparator<File>() {

				@Override
				public int compare(File o1, File o2) {
					return o1.getName().compareToIgnoreCase(o2.getName());
				}
			});
			for (int i = 0; i < files.length; i++) {
				renameFile(files[i], outputFolder, delete);
			}
		} else {
			// InputStream inStream = null;

			if (fileName.endsWith("fb2")) {
				if (!renameFileInFileStream(inFile, outputFolder)) {
					System.out.println("File " + fileName
							+ " can not be transformed. Skipping to next file");
					return;
				}
				if (delete) {
					inFile.delete();
				}
			} else if (fileName.endsWith("zip")) {
				ZipFile zipFile;
				try {
					zipFile = new ZipFile(inFile);
				} catch (ZipException e) {
					e.printStackTrace();
					System.out.println("File " + fileName
							+ " can not be transformed. Skipping to next file");
					return;
				} catch (IOException e) {
					e.printStackTrace();
					System.out.println("File " + fileName
							+ " can not be transformed. Skipping to next file");
					return;
				}
				Enumeration<? extends ZipEntry> entries = zipFile.entries();
				while (entries.hasMoreElements()) {
					ZipEntry element = entries.nextElement();
					if (!element.isDirectory()) {
						String name = element.getName();
						if (name.endsWith("fb2")) {
							if (!renameFileInZipStream(zipFile, element,
									outputFolder)) {
								System.out
										.println("File "
												+ fileName
												+ " can not be transformed. Skipping to next file");
							}

						}
					}
				}
				try {
					zipFile.close();
				} catch (IOException e) {
					e.printStackTrace();
					System.out.println("File " + fileName
							+ " can not be transformed. Skipping to next file");
				}
			}
		}

	}

	private static boolean renameFileInFileStream(File inFile,
			String outputFolder) {
		boolean parsed = false;
		for (int i = 0; i <= 1 && !parsed; i++) {
			try {
				InputStream inStream = getFilteredInputStream(
						new FileInputStream(inFile), i);
				renameFile(inStream, outputFolder);
				parsed = true;
			} catch (FileNotFoundException e) {
				return false;
			} catch (SAXException e) {
				// do nothing - go to next iteration
			} catch (TransformerException e) {
				// do nothing - go to next iteration
			} catch (IOException e) {
				return false;
			} catch (TransformerFactoryConfigurationError e) {
				return false;
			}
		}
		if (!parsed) {
			//dumpBadFile(inFile);
			return false;
		}
		return true;
	}

	private static void dumpBadFile(File inFile) {
		try {
			InputStream in = getFilteredInputStream(
					new FileInputStream(inFile), replacers.length);
			FileOutputStream out = new FileOutputStream(new File(inFile
					.getAbsolutePath()
					+ ".txt"));

			byte buf[] = new byte[1024];

			for (int length = in.read(buf); length > 0; length = in.read(buf)) {
				out.write(buf, 0, length);
			}
			in.close();
			out.close();

		} catch (FileNotFoundException e) {
		} catch (IOException e) {
		}
	}

	private static boolean renameFileInZipStream(ZipFile inFile,
			ZipEntry element, String outputFolder) {
		boolean parsed = false;
		for (int i = 0; i <= 1 && !parsed; i++) {
			try {
				InputStream inStream = getFilteredInputStream(inFile
						.getInputStream(element), i);
				renameFile(inStream, outputFolder);
				parsed = true;
			} catch (FileNotFoundException e) {
				return false;
			} catch (SAXException e) {
				// do nothing - go to next iteration
			} catch (TransformerException e) {
				// do nothing - go to next iteration
			} catch (IOException e) {
				return false;
			} catch (TransformerFactoryConfigurationError e) {
				return false;
			}
		}
		if (!parsed) {
			return false;
		}
		return true;
	}

	static class Replacement {
		Pattern expr;
		String replace;

		public Replacement(String expr, String replace) {
			super();
			this.expr = Pattern.compile(expr);
			this.replace = replace;
		}

		protected StringBuffer filter(StringBuffer in) {
			StringBuffer buf = new StringBuffer(in.length());
			Matcher m = expr.matcher(in);
			while (m.find()) {
				replace(m, buf);
			}
			m.appendTail(buf);
			return buf;
		}

		protected void replace(Matcher m, StringBuffer buf) {
			m.appendReplacement(buf, replace);
		}
	}
	
	static class TagReplacement extends Replacement {

		public TagReplacement() {
			super("<([^/\\?][^\\s>]*)([\\s/>])", "");
		}

		private static final HashSet<String> TAGS = new HashSet<String>();
		static {
			TAGS.add("FictionBook");
			TAGS.add("stylesheet");
			TAGS.add("description");
			TAGS.add("title-info");
			TAGS.add("genre");
			TAGS.add("author");
			TAGS.add("book-title");
			TAGS.add("annotation");
			TAGS.add("keywords");
			TAGS.add("date");
			TAGS.add("coverpage");
			TAGS.add("image");
			TAGS.add("lang");
			TAGS.add("src-lang");
			TAGS.add("translator");
			TAGS.add("sequence");
			TAGS.add("document-info");
			TAGS.add("program-used");
			TAGS.add("src-url");
			TAGS.add("src-ocr");
			TAGS.add("id");
			TAGS.add("version");
			TAGS.add("history");
			TAGS.add("publish-info");
			TAGS.add("book-name");
			TAGS.add("publisher");
			TAGS.add("city");
			TAGS.add("year");
			TAGS.add("isbn");
			TAGS.add("custom-info");
			TAGS.add("body");
			TAGS.add("image");
			TAGS.add("title");
			TAGS.add("epigraph");
			TAGS.add("section");
			TAGS.add("binary");
			TAGS.add("first-name");
			TAGS.add("middle-name");
			TAGS.add("last-name");
			TAGS.add("nickname");
			TAGS.add("home-page");
			TAGS.add("email");
			TAGS.add("p");
			TAGS.add("empty-line");
			TAGS.add("poem");
			TAGS.add("text-author");
			TAGS.add("epigraph");
			TAGS.add("stanza");
			TAGS.add("subtitle");
			TAGS.add("v");
			TAGS.add("cite");
			TAGS.add("annotation");
			TAGS.add("table");
			TAGS.add("strong");
			TAGS.add("emphasis");
			TAGS.add("style");
			TAGS.add("a");
			TAGS.add("tr");
			TAGS.add("td");
			
		}
		
		
		@Override
		protected void replace(Matcher m, StringBuffer buf) {
			
			String tagName = m.group(1);
			String suffix = m.group(2);
			String prefix = "\"";
			if (TAGS.contains(tagName)) {
				prefix = "<";
			}
			
			String replacement = prefix+tagName+suffix;
			String replacement1 = "";
			try {
				replacement1 = replacement.replaceAll("\\$", "S");
				m.appendReplacement(buf, replacement1);
			} catch (RuntimeException e) {
				e.printStackTrace();
				throw e;
			}
		}
		
	}

	static class EntityReplacement extends Replacement {

		public EntityReplacement() {
			super("&([^;\\s]+);", "");
		}

		private static final HashMap<String, String> ENTITY = new HashMap<String,String>();
		static {
			ENTITY.put("nbsp", "#160"); 
			ENTITY.put("iexcl", "#161"); 
			ENTITY.put("cent", "#162"); 
			ENTITY.put("pound", "#163"); 
			ENTITY.put("curren", "#164"); 
			ENTITY.put("yen", "#165"); 
			ENTITY.put("brvbar", "#166"); 
			ENTITY.put("sect", "#167"); 
			ENTITY.put("uml", "#168"); 
			ENTITY.put("copy", "#169"); 
			ENTITY.put("ordf", "#170"); 
			ENTITY.put("laquo", "#171"); 
			ENTITY.put("not", "#172"); 
			ENTITY.put("shy", "#173"); 
			ENTITY.put("reg", "#174"); 
			ENTITY.put("macr", "#175"); 
			ENTITY.put("deg", "#176"); 
			ENTITY.put("plusmn", "#177"); 
			ENTITY.put("sup2", "#178"); 
			ENTITY.put("sup3", "#179"); 
			ENTITY.put("acute", "#180"); 
			ENTITY.put("micro", "#181"); 
			ENTITY.put("para", "#182"); 
			ENTITY.put("middot", "#183"); 
			ENTITY.put("cedil", "#184"); 
			ENTITY.put("sup1", "#185"); 
			ENTITY.put("ordm", "#186"); 
			ENTITY.put("raquo", "#187"); 
			ENTITY.put("frac14", "#188"); 
			ENTITY.put("frac12", "#189"); 
			ENTITY.put("frac34", "#190"); 
			ENTITY.put("iquest", "#191"); 
			ENTITY.put("Agrave", "#192"); 
			ENTITY.put("Aacute", "#193"); 
			ENTITY.put("Acirc", "#194"); 
			ENTITY.put("Atilde", "#195"); 
			ENTITY.put("Auml", "#196"); 
			ENTITY.put("Aring", "#197"); 
			ENTITY.put("AElig", "#198"); 
			ENTITY.put("Ccedil", "#199"); 
			ENTITY.put("Egrave", "#200"); 
			ENTITY.put("Eacute", "#201"); 
			ENTITY.put("Ecirc", "#202"); 
			ENTITY.put("Euml", "#203"); 
			ENTITY.put("Igrave", "#204"); 
			ENTITY.put("Iacute", "#205"); 
			ENTITY.put("Icirc", "#206"); 
			ENTITY.put("Iuml", "#207"); 
			ENTITY.put("ETH", "#208"); 
			ENTITY.put("Ntilde", "#209"); 
			ENTITY.put("Ograve", "#210"); 
			ENTITY.put("Oacute", "#211"); 
			ENTITY.put("Ocirc", "#212"); 
			ENTITY.put("Otilde", "#213"); 
			ENTITY.put("Ouml", "#214"); 
			ENTITY.put("times", "#215"); 
			ENTITY.put("Oslash", "#216"); 
			ENTITY.put("Ugrave", "#217"); 
			ENTITY.put("Uacute", "#218"); 
			ENTITY.put("Ucirc", "#219"); 
			ENTITY.put("Uuml", "#220"); 
			ENTITY.put("Yacute", "#221"); 
			ENTITY.put("THORN", "#222"); 
			ENTITY.put("szlig", "#223"); 
			ENTITY.put("agrave", "#224"); 
			ENTITY.put("aacute", "#225"); 
			ENTITY.put("acirc", "#226"); 
			ENTITY.put("atilde", "#227"); 
			ENTITY.put("auml", "#228"); 
			ENTITY.put("aring", "#229"); 
			ENTITY.put("aelig", "#230"); 
			ENTITY.put("ccedil", "#231"); 
			ENTITY.put("egrave", "#232"); 
			ENTITY.put("eacute", "#233"); 
			ENTITY.put("ecirc", "#234"); 
			ENTITY.put("euml", "#235"); 
			ENTITY.put("igrave", "#236"); 
			ENTITY.put("iacute", "#237"); 
			ENTITY.put("icirc", "#238"); 
			ENTITY.put("iuml", "#239"); 
			ENTITY.put("eth", "#240"); 
			ENTITY.put("ntilde", "#241"); 
			ENTITY.put("ograve", "#242"); 
			ENTITY.put("oacute", "#243"); 
			ENTITY.put("ocirc", "#244"); 
			ENTITY.put("otilde", "#245"); 
			ENTITY.put("ouml", "#246"); 
			ENTITY.put("divide", "#247"); 
			ENTITY.put("oslash", "#248"); 
			ENTITY.put("ugrave", "#249"); 
			ENTITY.put("uacute", "#250"); 
			ENTITY.put("ucirc", "#251"); 
			ENTITY.put("uuml", "#252"); 
			ENTITY.put("yacute", "#253"); 
			ENTITY.put("thorn", "#254"); 
			ENTITY.put("yuml", "#255"); 
}
		
		
		@Override
		protected void replace(Matcher m, StringBuffer buf) {
			
			String entity = m.group(1);
			String replacement = "amp;"+entity; 
			if (ENTITY.containsKey(entity)) {
				replacement = ENTITY.get(entity);
			}
			replacement = "&"+replacement+";";
			String replacement1 = "";
			try {
				replacement1 = replacement.replaceAll("\\$", "S");
				m.appendReplacement(buf, replacement1);
			} catch (RuntimeException e) {
				e.printStackTrace();
				throw e;
			}
			
		}
		
	}
	
	static Replacement replacers[] = {
			new Replacement(
					"[\u0000\u0001\u0002\u0003\u0004\u0005\u0006\u0007\u0008\u0009\u000b\u000c\u000e\u000f\u0010\u0011\u0012\u0013\u0014\u0015\u0016\u0017\u0018\u0019\u001a\u001b\u001c\u001d\u001e\u001f]+",
					""), 
		    new Replacement("\\s&\\s", " &amp; "),
			new Replacement("&([^;\\n\\s&.]*[\\s&.])", "&amp;$1"),
			new Replacement("&([^;\\n\\s&.]*[\\s&.])", "&amp;$1"),
			new Replacement("(.)<\\?", "$1&lt;?"),
			new Replacement("<<+", "\""),
			new TagReplacement(),
			new EntityReplacement(),
			};

	private static final String ENCODING_PATTERN = "\\<\\?xml .*encoding=\"(.+)\".*\\?\\>"; //$NON-NLS-1$

	private static InputStream getFilteredInputStream(InputStream inStream,
			int level) {

		InputStream result = inStream;
		if (level > 0) {
			try {
				int length = inStream.available();
				byte[] bytes = new byte[length];

				inStream.read(bytes);
				String realEncoding = getRealEncoding(bytes);

				StringBuffer stringBuf = new StringBuffer(new String(bytes,
						realEncoding));

				for (int i = 0; i < replacers.length; i++) {
					stringBuf = replacers[i].filter(stringBuf);
				}
				result = new ByteArrayInputStream(stringBuf.toString()
						.getBytes(realEncoding));
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
		return result;
	}

	private static String getRealEncoding(byte[] bytes) {
		String enc = new String(bytes, 0, 1024);
		String realEncoding = "UTF-8"; //$NON-NLS-1$
		try {
			final Pattern p = Pattern.compile(ENCODING_PATTERN
					.toString());
			final Matcher matcher = p.matcher(enc);
			if (matcher.find()) {
				realEncoding = matcher.group(1);
			}
		} catch (final Throwable th) {
			th.printStackTrace();
		}
		return realEncoding;
	}

	private static void renameFile(InputStream inStream, String outputFolder)
			throws IOException, TransformerFactoryConfigurationError,
			TransformerException, SAXException {
		FictionBook book = new FictionBook(inStream);
		String bookName = book.getBookName();

		if (bookName == null) {
			throw new IOException("Bookname not found!!!");
		}
		System.out.println("Found book-name: " + bookName);

		String author = book.getAuthor();

		System.out.println("Found author: " + author);

		String seq = book.getSequence();

		System.out.println("Found sequence: " + seq);

		String seqNo = book.getSequenceNo();

		System.out.println("Found sequenceNo: " + seqNo);

		if (seqNo.length() > 0) {
			while (seqNo.length() < 3) {
				seqNo = "0" + seqNo;
			}
			bookName = seqNo + ". " + bookName;
		}

		author = author.replace(':', '_');
		author = author.replace('\\', '_');
		author = author.replace('/', '_');
		author = author.replace('<', '_');
		author = author.replace('>', '_');
		author = author.replace('?', '_');
		author = author.replace('"', '_');
		author = author.replace('\u2013', '-');
		author = author.replace('\u00AB', '_');
		author = author.replace('\u00BB', '_');

		seq = seq.replace(':', '_');
		seq = seq.replace('\\', '_');
		seq = seq.replace('/', '_');
		seq = seq.replace('<', '_');
		seq = seq.replace('>', '_');
		seq = seq.replace('?', '_');
		seq = seq.replace('"', '_');
		seq = seq.replace('\u2013', '-');
		seq = seq.replace('\u00AB', '_');
		seq = seq.replace('\u00BB', '_');

		bookName = bookName.replace(':', '_');
		bookName = bookName.replace('\\', '_');
		bookName = bookName.replace('/', '_');
		bookName = bookName.replace('<', '_');
		bookName = bookName.replace('>', '_');
		bookName = bookName.replace('?', '_');
		bookName = bookName.replace('"', '_');
		bookName = bookName.replace('"', '_');
		bookName = bookName.replace('\u2013', '-');
		bookName = bookName.replace('\u00AB', '_');
		bookName = bookName.replace('\u00BB', '_');

		String outFolderName = outputFolder + File.separator + author
				+ File.separator + seq;
		String bookFileName = bookName.substring(0, Math.min(64,bookName.length())) + ".fb2";
		String outFileName = outFolderName + File.separator + bookFileName
				+ ".zip";
		File f = new File(outFolderName);
		f.mkdirs();

		File f1 = new File(outFileName);
		if (!f1.exists()) {

			PackageCreator pc = new PackageCreator(outFileName);
			pc.addFileToPackage(book.getBookStream(), bookFileName);
			pc.close();
		}
	}

	/**
	 * Shows help text
	 */
	private static void showReadme() {
		try {
			BufferedReader readme = new BufferedReader(new InputStreamReader(
					Main.class.getClassLoader().getResourceAsStream(
							"readme.txt")));
			for (String s = readme.readLine(); s != null; s = readme.readLine()) {
				System.out.println(s);
			}
		} catch (IOException ex) {
		}
	}
}
