
FB2Library in an utility provides various functions to work with library in FB2 format.

Usage: java -jar FB2Library.jar <command> [options].

Where command is:
  cfn - convert file names. This command renames all files from input folder into output folder.
  cfnd - convert file names and delete input. This command renames all files from input folder into output folder and deletes source files.
  fsd - fix sequence declaration.
  