
FB2_2_Mobireader utility provides transformation of electronic book
from the Fiction Books to the Mobipocket prc format.

The original file is defined in a command line,
The new files will be created in the same folder.

Usage: java -jar FB2_2_Mobireader.jar source_file [output_directory]
    source_file      - the original fb2 file
    output_directory - directory where all produced files will be stored
