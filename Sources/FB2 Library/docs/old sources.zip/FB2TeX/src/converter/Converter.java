package converter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.w3c.dom.Document;

public class Converter {
	private static String defaultOutputPath = ":";

	public static void main(String[] args) {
		System.setProperty(
				"com.sun.org.apache.xalan.internal.serialize.encodings",
				Converter.class.getResource("Encodings.properties").toString());

		if (args.length < 1) {
			showReadme();
			System.exit(0);
		}
		if (args.length >= 2) {
			File f = new File(args[1]);
			if (f.isDirectory()) {
				defaultOutputPath = f.getAbsolutePath();
			}
		}

		try {

			String fileName = args[0];
			File f = new File(fileName);
			generate(f);
			System.out.println("Transformation finished.");
		} catch (Throwable th) {
			th.printStackTrace();
		}

	}

	/**
	 * Shows help text
	 */
	private static void showReadme() {
		try {
			BufferedReader readme = new BufferedReader(new InputStreamReader(
					Converter.class.getClassLoader().getResourceAsStream(
							"readme.txt")));
			for (String s = readme.readLine(); s != null; s = readme.readLine()) {
				System.out.println(s);
			}
		} catch (IOException ex) {
		}
	}

	private static void generate(File inputFile) throws IOException {
		String fileName = inputFile.getCanonicalPath();
		System.out.println("Loading file: " + fileName);

		if (inputFile.isDirectory()) {
			File[] files = inputFile.listFiles();
			for (int i = 0; i < files.length; i++) {
				generate(files[i]);
			}
		} else {
			if (fileName.endsWith("fb2")) {
				String outputFileName;
				if (":".equals(defaultOutputPath)) {
					outputFileName = getFileName(fileName, "tex");
				} else {
					outputFileName = getFileName(defaultOutputPath + "\\"
							+ inputFile.getName(), "tex");
				}
				InputStream fs = new FileInputStream(inputFile);

				transform(fs, outputFileName);
				return;
			}
			System.out.println("Skipping...");
		}
	}

	private static boolean transform(InputStream fs, String outputFileName) {

		System.out.println("Parsing...");
		Document document;
		try {
			DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
			// f.setNamespaceAware(true);
			DocumentBuilder b = f.newDocumentBuilder();
			document = b.parse(fs);
			System.out.println("FB2 file parsed succefully");
		} catch (Throwable th) {
			th.printStackTrace();
			System.out.println("FB2 file parse failed");
			return false;
		}

		System.out.println("Transforming fb2 document...");
		try {
			StreamSource xslForHtml = new StreamSource(Converter.class
					.getResourceAsStream("/xsl/FB2TeX.xsl"));

			FileOutputStream output = new FileOutputStream(outputFileName);

			DOMSource fb2FileSource = new DOMSource(document);
			StreamResult htmlFile = new StreamResult(output);

			Transformer t = TransformerFactory.newInstance().newTransformer(
					xslForHtml);

			t.setOutputProperty("encoding", "windows-1251");
			t.transform(fb2FileSource, htmlFile);

			output.flush();
			output.close();

			System.out.println("Transformation completed successfully");

			return true;
		} catch (Throwable th) {
			th.printStackTrace();
		}
		System.out.println("Transformation failed");
		return false;
	}

	public static String getFileName(String original, String ext) {
		int pos = original.lastIndexOf('.');
		if (pos >= 0) {
			return original.substring(0, pos) + "." + ext;
		} else {
			return original + "." + ext;
		}
	}

}
